v3: deep cmake detection; improved env generation
