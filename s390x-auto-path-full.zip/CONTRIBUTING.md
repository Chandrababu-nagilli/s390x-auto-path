# Contributing to s390x-auto-path

Thanks for taking an interest! Please open issues and PRs. Basic workflow:

1. Fork repo
2. Create a feature branch
3. Run tests: `pytest -q`
4. Make a PR to the main branch

Be conservative when rewriting .cmake files or patching rpaths -- changes are best-effort and optional flags control behavior.
